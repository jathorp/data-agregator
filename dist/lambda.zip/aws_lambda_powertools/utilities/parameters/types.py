from typing import Literal

TransformOptions = Literal["json", "binary", "auto", None]
