def main() -> None:
    print("Hello from data-aggregator!")
